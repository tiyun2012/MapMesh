﻿# MatchMesh Plugin (Maya 2026)

Minimal build focused on the dual-view UI and pin creation tools.

## Build
```pwsh
$env:DEVKIT_LOCATION = 'D:/MAYA/devkitBase2026_3'
$cm = 'C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/Common7/IDE/CommonExtensions/Microsoft/CMake/CMake/bin/cmake.exe'
& $cm -S $env:DEVKIT_LOCATION/devkit/plug-ins/MatchMesh -B $env:DEVKIT_LOCATION/build/MatchMesh -G "Visual Studio 17 2022" -A x64 -DMATCHMESH_USE_TBB=ON
& $cm --build $env:DEVKIT_LOCATION/build/MatchMesh --config Release
```
Output: `build/MatchMesh/bin/MatchMesh.mll`.

## Install / load
1) Copy or reference `MatchMesh.mll` in your Maya plug-in path.  
2) Maya 2026: Windows -> Settings/Preferences -> Plug-in Manager -> load `MatchMesh.mll` (enable auto-load if desired).

## Commands and tools
- `matchMeshDualViewUI;` -> Dual viewport UI (left=source, right=target) plus a dockable **MatchMesh Tools** toolbar.  
- `matchMeshCreatePin;` -> Create pin pair from selected components (source/target sets must be assigned).

## Dual-view UI (matchMeshDualViewUI)
- Always cleans old panels before rebuilding, preventing name collisions.  
- Dual-view panels: `matchMeshTargetPanel` (Target mesh), `matchMeshSourcePanel` (Source mesh), side-by-side.  
- Each panel uses its own camera; closing the UI deletes the MatchMesh target/source cameras.  
- A separate dockable **MatchMesh Tools** workspace control provides: Set Source, Set Target, Create Pin (no selection = origin; single component places both pins).

## Workflow quickstart
```mel
// 1) Open dual UI and load panels
matchMeshDualViewUI;
// 2) Set source/target meshes (toolbar)
//    Select a mesh transform, then click Set Source / Set Target
// 3) Create pin pairs from component selections
//    Select a component on source and a component on target, then click Create Pin
```

## Node attributes
- Locator: `MatchMeshPin` with `pinType` (Source/Target), `radius`, `active`, `partnerMatrix` (spare slot for partner info).

## Cleanup / unload
Unloading the plugin deletes MatchMesh UI controls and any MatchMesh pins.

## Testing snippets
```mel
// Basic pin pair
polySphere -r 2 -sx 30 -sy 30 -n custom;
polySphere -r 1.5 -sx 30 -sy 30 -n target;
select -r custom; matchMeshSetSourceMesh;
select -r target; matchMeshSetTargetMesh;
// Dual view
matchMeshDualViewUI;
```
#   M a p M e s h  
 #   M a p M e s h  
 
